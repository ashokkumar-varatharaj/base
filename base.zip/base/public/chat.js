$(() => {
  var socket = io.connect("http://localhost:5000");
});
